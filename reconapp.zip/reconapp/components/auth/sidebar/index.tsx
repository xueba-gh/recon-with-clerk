export const Sidebar = () => {
    return(
        <div className="sidebar"> Sidebar!</div>
    )
}