export default {
    providers: [
        {
            domain: "https://relaxed-grubworm-69.clerk.accounts.dev/",
            applicationID: "convex",
        },
    ]
}; 