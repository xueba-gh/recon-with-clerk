"use client";
import { Loading } from "@/components/auth/loading";
import { ClerkProvider, useAuth } from "@clerk/clerk-react";
import { AuthLoading, Authenticated, ConvexReactClient, Unauthenticated } from "convex/react";
import { ConvexProviderWithClerk } from "convex/react-clerk";

interface ConvexClientProviderProps {
    children: React.ReactNode;
};


const convexUrl = process.env.NEXT_PUBLIC_CONVEX_URL!;
const convex = new ConvexReactClient(convexUrl);

// Assuming ConvexProviderWithClerk is not needed or doesn't handle authentication logic

export const ConvexClientProvider = ({children}: 
    ConvexClientProviderProps) => {
 return(
   // <ClerkProvider afterSignOutUrl="/sign-up">
        
<ClerkProvider
  publishableKey="pk_test_cmVsYXhlZC1ncnVid29ybS02OS5jbGVyay5hY2NvdW50cy5kZXYk"
  signUpUrl="/sign-up" // Optional, redirect after sign-out
 // routerPush={handleSignOutRedirect} // Pass the redirection function
>
        
        <ConvexProviderWithClerk useAuth={useAuth} client={convex}>
            <AuthLoading> <Loading /> </AuthLoading>
            <Authenticated> {children} </Authenticated>
            <Unauthenticated> {children} </Unauthenticated>
        </ConvexProviderWithClerk>

    </ClerkProvider>
 )
    };
