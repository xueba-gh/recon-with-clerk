
"use client";
import { ClerkProvider } from '@clerk/nextjs';
import { ConvexProvider, ConvexReactClient } from 'convex/react';
import { Inter } from 'next/font/google';
import './globals.css';
import { metadata as siteMetadata } from './metadata'; // Import the metadata

const inter = Inter({ subsets: ["latin"] });

const convexClient = new ConvexReactClient("https://bright-bass-928.convex.cloud"); // Correct URL format

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <title>{siteMetadata.title}</title>
        <meta name="description" content={siteMetadata.description} />
      </head>
      <body className={inter.className}>
        <ClerkProvider>
          <ConvexProvider client={convexClient}>
            {children}
          </ConvexProvider>
        </ClerkProvider>
      </body>
    </html>
  );
}


// "use client";
// import { ClerkProvider } from '@clerk/nextjs';
// import { ConvexProvider, ConvexReactClient } from 'convex/react';
// import { Inter } from 'next/font/google';
// import "./globals.css";
// import { metadata as siteMetadata } from './metadata'; // Import the metadata

// const inter = Inter({ subsets: ["latin"] });

// const convexClient = new ConvexReactClient("https://bright-bass-928.convex.cloud"); // Use URL directly

// export default function RootLayout({
//   children,
// }: {
//   children: React.ReactNode;
// }) {
//   return (
//     <html lang="en">
//       <head>
//         <title>{siteMetadata.title}</title>
//         <meta name="description" content={siteMetadata.description} />
//       </head>
//       <body className={inter.className}>
//         <ClerkProvider>
//           <ConvexProvider client={convexClient}>
//             {children}
//           </ConvexProvider>
//         </ClerkProvider>
//       </body>
//     </html>
//   );
// }
