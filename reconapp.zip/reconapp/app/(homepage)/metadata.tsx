// app/metadata.ts
export const metadata = {
    title: "ReconAI",
    description: "New Revolution",
  };
  